package com.example.reminder3;

import java.util.Calendar;

public class Reminder {
    private int reminderID;
    private String reminderSubject;
    private String reminderText;
    private String reminderPriority;
    private Calendar reminderDate;

    public Reminder(){
        reminderID = -1;
        reminderDate = Calendar.getInstance();
    }
    public int getReminderID() {
        return reminderID;
    }
    public void setReminderID(int reminderID) {
        this.reminderID = reminderID;
    }
    public String getReminderPriority() {
        return reminderPriority;
    }

    public void setReminderPriority(String reminderPriority) {
        this.reminderPriority = reminderPriority;
    }

    public String getReminderText() {
        return reminderText;
    }

    public void setReminderText(String reminderText) {
        this.reminderText = reminderText;
    }

    public String getReminderSubject() {
        return reminderSubject;
    }

    public void setReminderSubject(String reminderSubject) {
        this.reminderSubject = reminderSubject;
    }
    public Calendar getReminderDate() {
        return reminderDate;
    }

    public void setReminderDate(Calendar reminderDate) {
        this.reminderDate = reminderDate;
    }
}
