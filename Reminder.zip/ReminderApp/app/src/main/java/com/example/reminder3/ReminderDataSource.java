package com.example.reminder3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;

import androidx.annotation.RequiresApi;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;

public class ReminderDataSource {
    private SQLiteDatabase database;
    private ReminderDBHelper dbHelper;

    public ReminderDataSource(Context context) {
        dbHelper = new ReminderDBHelper(context);
    }
    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }
    public void close(){
        dbHelper.close();
    }

    public boolean insertReminder(Reminder r) {
        boolean didSucceed = false;
        try {
            ContentValues initialValues = new ContentValues();
            initialValues.put("remindersubject", r.getReminderSubject());
            initialValues.put("remindertext", r.getReminderText());
            initialValues.put("reminderpriority", r.getReminderPriority());
            initialValues.put("reminderdate", String.valueOf(r.getReminderDate().getTimeInMillis()));
            didSucceed = database.insert("reminder", null, initialValues) > 0;
        } catch (Exception e) {
            //do nothing -will return false if there is an exception
        }
        return didSucceed;
    }
    public boolean updateReminder(Reminder r) {
        boolean didSucceed = false;
        try {
            Long rowId = (long) r.getReminderID();
            ContentValues updateValues = new ContentValues();
            updateValues.put("remindersubject", r.getReminderSubject());
            updateValues.put("remindertext", r.getReminderText());
            updateValues.put("reminderpriority", r.getReminderPriority());
            updateValues.put("reminderdate", String.valueOf(r.getReminderDate().getTimeInMillis()));

            didSucceed = database.update("reminder", updateValues, "_id=" + rowId, null) > 0;
        }
        catch(Exception e){

        }
        return didSucceed;
    }
    public int getLastReminderID() {
        int lastId;
        try {
            String query = "Select MAX(_id) from reminder";
            Cursor cursor = database.rawQuery(query, null);

            cursor.moveToFirst();
            lastId = cursor.getInt(0);
            cursor.close();
        }
        catch (Exception e) {
            lastId = -1;
        }
        return lastId;
    }
    public boolean deleteReminder(int reminderID) {
        boolean didDelete = false;
        try {
            didDelete = database.delete("reminder", "_id = " + reminderID, null) > 0;
        }
        catch(Exception e) {
            //Do nothing -return value already set to false
        }
        return didDelete;
    }
    @RequiresApi(api = Build.VERSION_CODES.N)
    public ArrayList<Reminder> getReminders(){
        ArrayList<Reminder> reminders = new ArrayList<Reminder>();
        try {
            String query = "SELECT * FROM reminder";
            Cursor cursor = database.rawQuery(query, null);

            Reminder newReminder;
            cursor.moveToFirst();
            while(!cursor.isAfterLast()) {
                newReminder = new Reminder();
                newReminder.setReminderID(cursor.getInt(0));
                newReminder.setReminderSubject(cursor.getString(1));
                newReminder.setReminderText(cursor.getString(2));
                newReminder.setReminderPriority(cursor.getString(3));
                Calendar calendar = Calendar.getInstance();
                calendar.setTimeInMillis(Long.valueOf(cursor.getString(4)));
                newReminder.setReminderDate(calendar);
                reminders.add(newReminder);
                cursor.moveToNext();
            }
            cursor.close();
        }
        catch(Exception e){
            reminders = new ArrayList<Reminder>();
        }
        return reminders;
    }
    @RequiresApi(api = Build.VERSION_CODES.N)
    public Reminder getSpecificReminder(int reminderId) {
        Reminder reminder = new Reminder();
        String query = "SELECT * FROM reminder WHERE _id =" + reminderId;
        Cursor cursor = database.rawQuery(query, null);

        if(cursor.moveToFirst()) {
            reminder.setReminderID(cursor.getInt(0));
            reminder.setReminderSubject(cursor.getString(1));
            reminder.setReminderText(cursor.getString(2));
            reminder.setReminderPriority(cursor.getString(3));
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(Long.valueOf(cursor.getString(4)));
            reminder.setReminderDate(calendar);

            cursor.close();
        }
        return reminder;
    }

    public ArrayList<Reminder> getReminder(String sortfield, String sortOrder){
        ArrayList<Reminder> reminder = new ArrayList<Reminder>();
        try {
            String query = "SELECT * FROM reminder ORDER BY " + sortfield + " " + sortOrder;
            Cursor cursor = database.rawQuery(query, null);
            Reminder newReminder;
            cursor.moveToFirst();
            while(!cursor.isAfterLast()){
                newReminder = new Reminder();
                newReminder.setReminderID(cursor.getInt(0));
                newReminder.setReminderSubject(cursor.getString(1));
                newReminder.setReminderText(cursor.getString(2));
                newReminder.setReminderPriority(cursor.getString(3));
                Calendar calendar = Calendar.getInstance();
                calendar.setTimeInMillis(Long.valueOf(cursor.getString(4)));
                newReminder.setReminderDate(calendar);
                reminder.add(newReminder);
                cursor.moveToNext();
            }
            cursor.close();
        }
        catch(Exception e){
            reminder = new ArrayList<Reminder>();
        }
        return reminder;
    }

}
