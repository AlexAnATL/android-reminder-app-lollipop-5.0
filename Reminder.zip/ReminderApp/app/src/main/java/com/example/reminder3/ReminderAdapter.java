package com.example.reminder3;

import android.content.Context;
import android.graphics.Color;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class ReminderAdapter extends RecyclerView.Adapter {
    private ArrayList<Reminder> reminderData;
    private View.OnClickListener mOnItemClickListener;
    private boolean isDeleting;
    private Context parentContext;

    public class ReminderViewHolder extends RecyclerView.ViewHolder {

        public TextView textViewListSubject;
        public TextView textViewListReminderText;
        public TextView textViewListPriority;
        public TextView textViewListDate;
        public ConstraintLayout constraintListItem;
        public Button buttonListDelete;

        public ReminderViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewListSubject = itemView.findViewById(R.id.textViewListSubject);
            textViewListReminderText = itemView.findViewById(R.id.textViewListReminderText);
            textViewListPriority = itemView.findViewById(R.id.textViewListPriority);
            textViewListDate = itemView.findViewById(R.id.textViewListDate);
            buttonListDelete = itemView.findViewById(R.id.buttonListDelete);
            constraintListItem = itemView.findViewById(R.id.constraintListItem);
            itemView.setTag(this);
            itemView.setOnClickListener(mOnItemClickListener);
        }
        public ConstraintLayout getConstraintListItem(){
            return constraintListItem;
        }
        public TextView getTextViewListSubject(){
            return textViewListSubject;
        }
        public TextView getTextViewListReminderText(){
            return textViewListReminderText;
        }
        public TextView getTextViewListPriority(){
            return textViewListPriority;
        }
        public TextView getTextViewListDate(){
            return textViewListDate;
        }
        public Button getButtonListDelete() {
            return buttonListDelete;
        }
    }
    public ReminderAdapter(ArrayList<Reminder> arrayList, Context context) {
        reminderData = arrayList;
        parentContext = context;
    }
    public void setOnItemClickListener(View.OnClickListener itemClickListener) {
        mOnItemClickListener = itemClickListener;
    }
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item, parent, false);
        return new ReminderViewHolder(v);
    }
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ReminderViewHolder rvh = (ReminderViewHolder) holder;
       if(reminderData.get(position).getReminderPriority().compareTo("High") == 0 ){
           rvh.getTextViewListPriority().setTextColor(Color.parseColor("#FFFA1313"));
       } else if(reminderData.get(position).getReminderPriority().compareTo("Medium") == 0){
           rvh.getTextViewListPriority().setTextColor(Color.parseColor("#FFFB00"));
       } else {
           rvh.getTextViewListPriority().setTextColor(Color.parseColor("#40F80E"));
       }
        rvh.getTextViewListSubject().setText(reminderData.get(position).getReminderSubject());
        rvh.getTextViewListReminderText().setText(reminderData.get(position).getReminderText());
        rvh.getTextViewListPriority().setText(reminderData.get(position).getReminderPriority());
        rvh.getTextViewListDate().setText(DateFormat.format("MM/dd/yy", reminderData.get(position).getReminderDate().getTimeInMillis()).toString());
        if (isDeleting)  {
            rvh.getButtonListDelete().setVisibility(View.VISIBLE);
            rvh.getButtonListDelete().setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    deleteItem(position);
                }
            });
        } else {
            rvh.getButtonListDelete().setVisibility(View.INVISIBLE);
        }
    }
    public void setDelete(boolean b) {
        isDeleting = b;
    }
    private void deleteItem(int position) {
        Reminder reminder = reminderData.get(position);
        ReminderDataSource ds = new ReminderDataSource(parentContext);
        try {
            ds.open();
            boolean didDelete = ds.deleteReminder(reminder.getReminderID());
            ds.close();
            if (didDelete) {
                reminderData.remove(position);
                notifyDataSetChanged();
            } else {
                Toast.makeText(parentContext, "Delete Failed!", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(parentContext, "Delete Failed!", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public int getItemCount() {
        return reminderData.size();
    }
}

