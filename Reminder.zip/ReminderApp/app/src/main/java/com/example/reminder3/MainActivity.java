package com.example.reminder3;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    private Reminder currentReminder;

    private void initTextChangedEvents () {
        final EditText etReminderSubject = findViewById(R.id.editTextSubject);
        etReminderSubject.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) {
                currentReminder.setReminderSubject(etReminderSubject.getText().toString());
            }

            public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
                //auto generated method stub
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
                //auto generated method stub
            }
        });
        final EditText etReminderText = findViewById(R.id.editTextReminder);
        etReminderText.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s){
                currentReminder.setReminderText(etReminderText.getText().toString());
            }
            @Override
            public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                //auto generated method stub
            }
        });
    }
    private void initSaveButton(){
        ImageButton saveButton = findViewById(R.id.imageButtonSave);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View view){
                boolean wasSuccessful;

                ReminderDataSource ds = new ReminderDataSource(MainActivity.this);
                try{
                    ds.open();
                    if(currentReminder.getReminderID() == -1){
                        wasSuccessful = ds.insertReminder(currentReminder);
                        if(wasSuccessful){
                            int newId = ds.getLastReminderID();
                            currentReminder.setReminderID(newId);

                        }
                    }
                    else {
                        wasSuccessful = ds.updateReminder(currentReminder);
                    }
                    ds.close();
                }
                catch(Exception e) {
                    wasSuccessful = false;
                }
                if(wasSuccessful) {
                    Toast.makeText(getBaseContext(), "Save Successful", Toast.LENGTH_LONG).show();
                }
                Intent intent = new Intent(MainActivity.this, ReminderActivityList.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }

        });
    }
    private void initPriorityRadioGroup(){
        RadioGroup radiogroupPriority = findViewById(R.id.radiogroupPriority);

        radiogroupPriority.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton radioButtonHigh = findViewById(R.id.radioButtonHigh);
                RadioButton radioButtonMedium = findViewById(R.id.radioButtonMedium);
                if(radioButtonHigh.isChecked()) {
                    currentReminder.setReminderPriority("High");
                }
                else if(radioButtonMedium.isChecked()){
                    currentReminder.setReminderPriority("Medium");
                }
                else{
                    currentReminder.setReminderPriority("Low");
                }
            }
        });
    }
    @RequiresApi(api = Build.VERSION_CODES.N)
    private void initReminder (int id){
        ReminderDataSource ds = new ReminderDataSource(MainActivity.this);
        try {
            ds.open();
            currentReminder = ds.getSpecificReminder(id);
            ds.close();
        }
        catch(Exception e) {
            Toast.makeText(this, "Load Reminder Failed", Toast.LENGTH_LONG).show();
        }
        EditText editTextReminderSubject = findViewById(R.id.editTextSubject);
        EditText editTextReminderText = findViewById(R.id.editTextReminder);
        RadioButton radioButtonHigh = findViewById(R.id.radioButtonHigh);
        RadioButton radioButtonMedium = findViewById(R.id.radioButtonMedium);
        RadioButton radioButtonLow = findViewById(R.id.radioButtonLow);



        editTextReminderSubject.setText(currentReminder.getReminderSubject());
        editTextReminderText.setText(currentReminder.getReminderText());
        if(currentReminder.getReminderPriority().compareTo("High") == 0) {
            radioButtonHigh.setChecked(true);
        }else if(currentReminder.getReminderPriority().compareTo("Medium") == 0) {
            radioButtonMedium.setChecked(true);
        }
        else{
            radioButtonLow.setChecked(true);
        }

    }


    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Bundle extras = getIntent().getExtras();
        if(extras != null)  {
            initReminder(extras.getInt("reminderID"));
        }
        else{
            currentReminder = new Reminder();
        }
        initPriorityRadioGroup();
        initSaveButton();
        initTextChangedEvents();
        initListButton();
        initSettingBtn();
    }

    private void initListButton(){
        ImageButton listBtn = findViewById(R.id.listBtn);
        listBtn.setOnClickListener(e -> {
            Intent intent = new Intent(MainActivity.this, ReminderActivityList.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });
    }

    private void initSettingBtn(){
        ImageButton listBtn = findViewById(R.id.settingBtn);
        listBtn.setOnClickListener(e -> {
            Intent intent = new Intent(MainActivity.this, ReminderSettingsActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });
    }

}