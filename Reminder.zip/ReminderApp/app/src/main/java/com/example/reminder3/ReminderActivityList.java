package com.example.reminder3;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ReminderActivityList extends Activity {
    public ArrayList<Reminder> reminders;
    public ReminderAdapter reminderAdapter;
    private View.OnClickListener onItemClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            RecyclerView.ViewHolder viewHolder = (RecyclerView.ViewHolder)
                    view.getTag();
            int position = viewHolder.getAdapterPosition();
            int reminderId = reminders.get(position).getReminderID();
            Intent intent = new Intent(ReminderActivityList.this, MainActivity.class);
            intent.putExtra("reminderID", reminderId);

            startActivity(intent);
        }
    };
    private void initDeleteSwitch() {
        Switch s = findViewById(R.id.switchDelete);
        s.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {

                Boolean status = compoundButton.isChecked();
                reminderAdapter.setDelete(status);
                reminderAdapter.notifyDataSetChanged();
            }
        });
    }
    private void initAddReminderButton() {
        Button buttonAddReminder = findViewById(R.id.buttonAddReminder);
        buttonAddReminder.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(ReminderActivityList.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }


    private void initSettingButton() {
        ImageButton buttonSetting = findViewById(R.id.SettingImageButton);
        buttonSetting.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(ReminderActivityList.this, ReminderSettingsActivity.class);
                startActivity(intent);
            }
        });
    }
    @RequiresApi(api = Build.VERSION_CODES.N)
    public void onResume() {
        super.onResume();
        String sortBy = getSharedPreferences("ReminderPreferences", Context.MODE_PRIVATE)
                .getString("sortfield", "remindersubject");
        String sortOrder = getSharedPreferences("ReminderPreferences", Context.MODE_PRIVATE)
                .getString("sortorder", "ASC");
        ReminderDataSource ds = new ReminderDataSource(this);

        try {
            ds.open();
            reminders = ds.getReminder(sortBy, sortOrder);
            ds.close();

            if (reminders.size() > 0) {
                RecyclerView reminderList = findViewById(R.id.rvReminders);
                RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
                reminderList.setLayoutManager(layoutManager);
                reminderAdapter = new ReminderAdapter(reminders, this);
                reminderAdapter.setOnItemClickListener(onItemClickListener);
                reminderList.setAdapter(reminderAdapter);
            }else{
                Intent intent = new Intent(ReminderActivityList.this, MainActivity.class);
                startActivity(intent);
            }
        } catch(Exception e){
            Toast.makeText(this, "Error retrieving reminders", Toast.LENGTH_LONG).show();
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder_list);
        initDeleteSwitch();
        initAddReminderButton();
        initSettingButton();
    }
}
